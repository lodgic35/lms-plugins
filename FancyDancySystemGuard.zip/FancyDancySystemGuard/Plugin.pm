package Plugins::FancyDancySystemGuard::Plugin;

# Fancy-Dancy System Guard - LMS Plugin v1.0
# Installs and monitors the LMS process watchdog script on piCorePlayer.
# The watchdog script runs independently of LMS and monitors the LMS process.
# If LMS becomes unresponsive it restarts it. If restart fails it reboots the Pi.

use strict;
use base qw(Slim::Plugin::Base);

use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Slim::Utils::Timers;
use File::Spec;

my $log = Slim::Utils::Log->addLogCategory({
    'category'     => 'plugin.fancydancysystemguard',
    'defaultLevel' => 'INFO',
    'description'  => 'Fancy-Dancy System Guard',
});

my $prefs = preferences('plugin.fancydancysystemguard');

$prefs->init({
    enabled          => 1,
    script_installed => 0,
    last_check       => 0,
});

# Where we install the watchdog script
my $SCRIPT_DEST    = '/mnt/mmcblk0p2/tce/lms_watchdog.sh';
my $BOOTLOCAL      = '/opt/bootlocal.sh';
my $BOOTLOCAL_ENTRY = '/mnt/mmcblk0p2/tce/lms_watchdog.sh &';

# ---------------------------------------------------------------------------
# Plugin initialisation
# ---------------------------------------------------------------------------
sub initPlugin {
    my $class = shift;
    $class->SUPER::initPlugin(@_);

    require Plugins::FancyDancySystemGuard::Settings;
    Plugins::FancyDancySystemGuard::Settings->new($class);

    # Run install/health check after a short delay on startup
    Slim::Utils::Timers::setTimer(
        undef,
        Time::HiRes::time() + 10,
        \&_startupCheck
    );

    $log->info("Fancy-Dancy System Guard v1.0 initialised");
}

# ---------------------------------------------------------------------------
# Startup check - install script if needed, verify it's running
# ---------------------------------------------------------------------------
sub _startupCheck {
    return unless $prefs->get('enabled');

    $log->info("Running startup check...");

    if (!-f $SCRIPT_DEST) {
        $log->info("Watchdog script not found - installing...");
        _installScript();
    } else {
        $log->info("Watchdog script found at $SCRIPT_DEST");
        _ensureRunning();
    }

    $prefs->set('last_check', time());
}

# ---------------------------------------------------------------------------
# Install the bundled watchdog script
# ---------------------------------------------------------------------------
sub _installScript {
    # Find the bundled script inside the plugin directory
    my $pluginDir  = Slim::Utils::PluginManager->allPlugins->{'FancyDancySystemGuard'}{basedir};
    my $scriptSrc  = File::Spec->catfile($pluginDir, 'scripts', 'lms_watchdog.sh');

    unless (-f $scriptSrc) {
        $log->error("Bundled script not found at: $scriptSrc");
        return 0;
    }

    # Copy script to persistent partition
    my $result = system("cp '$scriptSrc' '$SCRIPT_DEST' && chmod +x '$SCRIPT_DEST'");
    if ($result != 0) {
        $log->error("Failed to copy watchdog script to $SCRIPT_DEST");
        return 0;
    }
    $log->info("Watchdog script installed to $SCRIPT_DEST");

    # Add to bootlocal.sh if not already there
    _addToBootlocal();

    # Backup piCorePlayer settings
    $log->info("Running pcp bu to save changes...");
    system("/usr/local/bin/pcp bu >/dev/null 2>&1 &");

    # Start the script now
    _startScript();

    $prefs->set('script_installed', 1);
    $log->info("Watchdog script installation complete");
    return 1;
}

# ---------------------------------------------------------------------------
# Add entry to bootlocal.sh if not already present
# ---------------------------------------------------------------------------
sub _addToBootlocal {
    # Check if entry already exists
    my $exists = 0;
    if (open(my $fh, '<', $BOOTLOCAL)) {
        while (<$fh>) {
            if (/lms_watchdog/) {
                $exists = 1;
                last;
            }
        }
        close($fh);
    }

    if ($exists) {
        $log->info("bootlocal.sh entry already present");
        return;
    }

    # Append entry
    if (open(my $fh, '>>', $BOOTLOCAL)) {
        print $fh "\n$BOOTLOCAL_ENTRY\n";
        close($fh);
        $log->info("Added watchdog to bootlocal.sh");
    } else {
        $log->error("Could not write to $BOOTLOCAL: $!");
    }
}

# ---------------------------------------------------------------------------
# Start the watchdog script if not already running
# ---------------------------------------------------------------------------
sub _startScript {
    if (_isScriptRunning()) {
        $log->info("Watchdog script already running");
        return;
    }

    if (-f $SCRIPT_DEST) {
        system("$SCRIPT_DEST &");
        $log->info("Watchdog script started");
    } else {
        $log->error("Cannot start - script not found at $SCRIPT_DEST");
    }
}

# ---------------------------------------------------------------------------
# Check if watchdog script process is running
# ---------------------------------------------------------------------------
sub _isScriptRunning {
    my $result = system("pgrep -f lms_watchdog >/dev/null 2>&1");
    return $result == 0 ? 1 : 0;
}

# ---------------------------------------------------------------------------
# Ensure script is running - restart if it stopped
# ---------------------------------------------------------------------------
sub _ensureRunning {
    if (_isScriptRunning()) {
        $log->debug("Watchdog script is running");
    } else {
        $log->warn("Watchdog script not running - restarting...");
        _startScript();
    }
}

# ---------------------------------------------------------------------------
# Get current status for settings page
# ---------------------------------------------------------------------------
sub getStatus {
    my $installed = -f $SCRIPT_DEST ? 1 : 0;
    my $running   = _isScriptRunning();
    my $inBoot    = 0;

    if (open(my $fh, '<', $BOOTLOCAL)) {
        while (<$fh>) {
            if (/lms_watchdog/) { $inBoot = 1; last; }
        }
        close($fh);
    }

    my $lastCheck = $prefs->get('last_check') || 0;
    my $lastCheckStr = $lastCheck ? scalar(localtime($lastCheck)) : 'Never';

    return {
        installed   => $installed,
        running     => $running,
        inBoot      => $inBoot,
        lastCheck   => $lastCheckStr,
        scriptDest  => $SCRIPT_DEST,
    };
}

# ---------------------------------------------------------------------------
# Manual reinstall triggered from settings page
# ---------------------------------------------------------------------------
sub reinstall {
    $log->info("Manual reinstall requested");
    system("kill \$(pgrep -f lms_watchdog) 2>/dev/null");
    system("rm -f ${SCRIPT_DEST}");
    sleep(1);
    _installScript();
    $prefs->set('last_check', time());
}

sub getDisplayName { 'PLUGIN_FANCYDANCYSYSTEMGUARD' }
sub playerMenu     { undef }

1;
