package Plugins::FancyDancySystemGuard::Settings;

use strict;
use base qw(Slim::Web::Settings);

use Slim::Utils::Prefs;

my $prefs = preferences('plugin.fancydancysystemguard');

sub name { Slim::Web::HTTP::CSRF->protectName('PLUGIN_FANCYDANCYSYSTEMGUARD') }
sub page { Slim::Web::HTTP::CSRF->protectURI('plugins/FancyDancySystemGuard/settings/basic.html') }

sub prefs {
    return ($prefs, qw(enabled));
}

sub handler {
    my ($class, $client, $paramRef, $pageSetup) = @_;

    if ($paramRef->{saveSettings}) {
        # Trigger reinstall if requested
        if ($paramRef->{reinstall}) {
            Plugins::FancyDancySystemGuard::Plugin::reinstall();
        }
    }

    # Get current status for display
    $paramRef->{status} = Plugins::FancyDancySystemGuard::Plugin::getStatus();

    return $class->SUPER::handler($client, $paramRef, $pageSetup);
}

1;
