package Plugins::SpottyCapture::Settings;

use strict;
use warnings;
use base qw(Slim::Web::Settings);

use Slim::Utils::Prefs;
use Slim::Utils::Log;

my $prefs = preferences('plugin.spottycapture');
my $log   = logger('plugin.spottycapture');

sub name { return Slim::Web::HTTP::CSRF->protectName('PLUGIN_SPOTTYCAPTURE_NAME') }
sub page { return Slim::Web::HTTP::CSRF->protectURI('plugins/spottycapture/settings.html') }
sub prefs { return ($prefs, qw(enabled outputDir alsaDev bitrate)) }

sub handler {
    my ($class, $client, $params) = @_;

    # Handle enable/disable toggle
    if (defined $params->{enabled}) {
        my $newState = $params->{enabled} ? 1 : 0;
        my $oldState = $prefs->get('enabled');

        $prefs->set('enabled', $newState);

        if ($newState && !$oldState) {
            $log->info("SpottyCapture enabled via settings.");
        } elsif (!$newState && $oldState) {
            $log->info("SpottyCapture disabled via settings.");
            # Stop any active captures
            Plugins::SpottyCapture::Plugin::_stopCapture($_)
                for keys %Plugins::SpottyCapture::Plugin::captureProc;
        }
    }

    # Dependency check for display
    $params->{depStatus} = _checkDeps();

    return $class->SUPER::handler($client, $params);
}

sub _checkDeps {
    my @deps;
    for my $cmd (qw(ffmpeg curl perl)) {
        my $ok = (system("which $cmd >/dev/null 2>&1") == 0);
        push @deps, { name => $cmd, ok => $ok };
    }
    # Check loopback
    my $lb = (`aplay -l 2>/dev/null` =~ /Loopback/) ? 1 : 0;
    push @deps, { name => 'ALSA Loopback (snd-aloop)', ok => $lb };
    return \@deps;
}

1;
