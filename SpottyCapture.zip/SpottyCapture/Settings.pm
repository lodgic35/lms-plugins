package Plugins::SpottyCapture::Settings;

use strict;
use base qw(Slim::Web::Settings);

use Slim::Utils::Prefs;
use Slim::Utils::Log;

my $prefs = preferences('plugin.spottycapture');
my $log   = logger('plugin.spottycapture');

sub name { Slim::Web::HTTP::CSRF->protectName('PLUGIN_SPOTTYCAPTURE_SETTINGS') }

sub page { Slim::Web::HTTP::CSRF->protectURI('plugins/SpottyCapture/settings/basic.html') }

sub prefs {
    return ($prefs, qw(enabled outputDir alsaDev bitrate useNas nasDir endTrim));
}

sub handler {
    my ($class, $client, $paramRef, $pageSetup) = @_;

    if ($paramRef->{saveSettings}) {
        if (!$paramRef->{pref_enabled} && $prefs->get('enabled')) {
            $log->info("SpottyCapture disabled — stopping active captures.");
            Plugins::SpottyCapture::Plugin::_stopCapture($_)
                for keys %Plugins::SpottyCapture::Plugin::captureProc;
        }
    }

    $paramRef->{depStatus} = _checkDeps();

    my $sqOutput = _getSqueezeliteOutput();
    $paramRef->{squeezeliteWarn} = ($sqOutput ne 'splitout') ? 1 : 0;
    $paramRef->{currentOutput}   = $sqOutput;
    $paramRef->{serverIP}        = Slim::Utils::Network::serverAddr();

    my $nasDir   = $prefs->get('nasDir') || '/mnt/nas/Spotify';
    my $nasMount = $nasDir;
    $nasMount =~ s|(/mnt/[^/]+).*|$1|;
    $paramRef->{nasMounted} = (-d $nasMount && $nasMount ne '/mnt') ? 1 : 0;
    $paramRef->{nasMount}   = $nasMount;

    return $class->SUPER::handler($client, $paramRef, $pageSetup);
}

sub _checkDeps {
    my @deps;
    for my $cmd (qw(ffmpeg curl perl)) {
        my $ok = (system("which $cmd >/dev/null 2>&1") == 0);
        push @deps, { name => $cmd, ok => $ok };
    }
    my $lb = (`aplay -l 2>/dev/null` =~ /Loopback/) ? 1 : 0;
    push @deps, { name => 'ALSA Loopback (snd-aloop)', ok => $lb };
    return \@deps;
}

sub _getSqueezeliteOutput {
    my $cfg = '/usr/local/etc/pcp/pcp.cfg';
    if (open(my $fh, '<', $cfg)) {
        while (my $line = <$fh>) {
            if ($line =~ /^OUTPUT="([^"]*)"/) {
                close $fh;
                return $1;
            }
        }
        close $fh;
    }
    return 'unknown';
}

1;
