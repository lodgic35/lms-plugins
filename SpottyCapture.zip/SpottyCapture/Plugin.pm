package Plugins::SpottyCapture::Plugin;

use strict;
use base qw(Slim::Plugin::Base);

use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Slim::Utils::Timers;
use Slim::Control::Request;
use Time::HiRes qw(time);

my $log = Slim::Utils::Log->addLogCategory({
    'category'     => 'plugin.spottycapture',
    'defaultLevel' => 'INFO',
    'description'  => 'Spotty Capture',
});

my $prefs = preferences('plugin.spottycapture');

$prefs->init({
    enabled     => 0,
    outputDir   => '/mnt/mmcblk0p2/Spotty',
    alsaDev     => 'plughw:Loopback,1,0',
    bitrate     => '320k',
    useNas      => 0,
    nasDir      => '/mnt/nas/Spotify',
    endTrim     => 2.0,
    startDelay  => 0,
    syncEnabled => 0,
    syncDir     => '/mnt/nas/Spotify',
});

use constant TOGGLE_URL => 'plugins/SpottyCapture/toggle';
use constant ICON       => 'plugins/SpottyCapture/html/images/icon.png';

# Keyed by player ID — tracks active capture PIDs
our %captureProc;
# Keyed by player ID — guards against duplicate prebuffer starts
my %startingPrebuf;

sub initPlugin {
    my $class = shift;
    $class->SUPER::initPlugin(@_);

    require Plugins::SpottyCapture::Settings;
    Plugins::SpottyCapture::Settings->new($class);

    # Setup sync cron job if enabled
    _updateCron();

    # Startup sweep: kill any orphaned capture ffmpeg from a previous run and
    # remove stale prebuffer/sidecar files. Prevents a zombie ffmpeg (e.g. left
    # by a hard kill or power loss) from holding the loopback and breaking all
    # captures. Matches only our own prebuffer ffmpeg, never user playback.
    _sweepStaleCaptures();

    # Ensure capture.sh is executable — zip installs strip execute permissions
    my $script = _pluginDir() . '/Bin/capture.sh';
    chmod 0755, $script if -f $script && !-x $script;

    # Register CLI command for controller app toggle
    Slim::Control::Request::addDispatch(
        ['spottycapture', '_cmd'],
        [0, 1, 0, \&_cliHandler]
    );

    # Register web UI Extras menu item with toggle page
    Slim::Web::Pages->addPageFunction(TOGGLE_URL, \&_togglePage);

    # Register setup page
    Slim::Web::Pages->addPageFunction('plugins/SpottyCapture/setup', \&_setupPage);

    # Register sync now page
    Slim::Web::Pages->addPageFunction('plugins/SpottyCapture/sync', \&_syncPage);
    Slim::Web::Pages->addPageLinks('plugins', {
        'PLUGIN_SPOTTYCAPTURE_NAME' => TOGGLE_URL
    });
    Slim::Web::Pages->addPageLinks('icons', {
        'PLUGIN_SPOTTYCAPTURE_NAME' => ICON
    });

    # Register Jive/controller app home screen item
    Slim::Control::Jive::registerPluginMenu([{
        text    => 'PLUGIN_SPOTTYCAPTURE_NAME',
        id      => 'spottyCaptureToggle',
        node    => 'plugins',
        weight  => 100,
        actions => {
            go => {
                cmd    => ['spottycapture', 'toggle'],
                player => 0,
            },
        },
    }]);

    Slim::Control::Request::subscribe(
        \&_playerEvent,
        [['playlist'], ['newsong', 'stop', 'pause']],
    );

    $log->info("SpottyCapture initialised. Enabled: " . ($prefs->get('enabled') ? 'yes' : 'no')
        . ". Output: " . _outputDir());
}

# ---------------------------------------------------------------------------
# Web UI toggle page — shows current state, toggles on button click
# ---------------------------------------------------------------------------
sub _togglePage {
    my ($client, $params) = @_;

    if ($params->{action} && $params->{action} eq 'toggle') {
        my $newState = $prefs->get('enabled') ? 0 : 1;
        $prefs->set('enabled', $newState);

        if (!$newState) {
            $log->info("SpottyCapture disabled via Extras toggle.");
            _stopCapture($_, 1) for keys %captureProc;
        } else {
            $log->info("SpottyCapture enabled via Extras toggle.");
        }
    }

    $params->{enabled}   = $prefs->get('enabled') ? 1 : 0;
    $params->{outputDir} = _outputDir();

    return Slim::Web::HTTP::filltemplatefile(
        'plugins/SpottyCapture/html/toggle.html', $params);
}

# ---------------------------------------------------------------------------
# Setup page — runs setup.sh and returns JSON results
# ---------------------------------------------------------------------------
sub _setupPage {
    my ($client, $params) = @_;

    my $script = _pluginDir() . '/Bin/setup.sh';
    unless (-x $script) {
        chmod 0755, $script if -f $script;
    }

    my $json = `$script 2>/dev/null` || '[]';
    chomp $json;

    $params->{setupResults} = $json;
    $params->{ran} = 1;

    return Slim::Web::HTTP::filltemplatefile(
        'plugins/SpottyCapture/settings/basic.html', $params);
}

# ---------------------------------------------------------------------------
# CLI handler
# ---------------------------------------------------------------------------
sub _cliHandler {
    my $request = shift;
    my $cmd     = $request->getParam('_cmd') // '';

    if ($cmd eq 'toggle') {
        my $newState = $prefs->get('enabled') ? 0 : 1;
        $prefs->set('enabled', $newState);

        if (!$newState) {
            $log->info("SpottyCapture disabled via CLI toggle.");
            _stopCapture($_, 1) for keys %captureProc;
        } else {
            $log->info("SpottyCapture enabled via CLI toggle.");
        }

        $request->addResult('enabled', $newState);
        $request->addResult('text',
            $newState ? 'Spotty Capture: ON' : 'Spotty Capture: OFF');
    }
    elsif ($cmd eq 'status') {
        $request->addResult('enabled', $prefs->get('enabled') ? 1 : 0);
        $request->addResult('output', _outputDir());
    }

    $request->setStatusDone();
}

sub _playerEvent {
    my $request = shift;
    my $client  = $request->client() or return;
    return unless $prefs->get('enabled');
    my $cmd = $request->getRequestString();
    if ($cmd =~ /newsong/) {
        _onNewSong($client);
    } elsif ($cmd =~ /stop|clear/) {
        _stopCapture($client->id(), 1);
    } elsif ($cmd =~ /pause/) {
        _stopCapture($client->id(), 0);
    }
}

sub _onNewSong {
    my ($client) = @_;
    my $playerID = $client->id();

    _stopCapture($playerID);

    my $song = Slim::Player::Playlist::song($client) or return;
    my $url  = $song->url() // '';

    unless ($url =~ /spotify|spotty/i) {
        $log->debug("Skipping non-Spotify track: $url");
        return;
    }

    # Generate unique prebuffer + sidecar filenames using timestamp
    my $ts       = int(time() * 1000);
    my $safeID   = $playerID;
    $safeID      =~ s/[^a-zA-Z0-9]/_/g;
    my $prebuf      = "/tmp/sc_pre_${safeID}_${ts}.mp3";
    my $metaSidecar = "/tmp/sc_meta_${safeID}_${ts}.sh";

    # Remove any stale sidecars from previous tracks
    for my $stale (glob("/tmp/sc_meta_${safeID}_*.sh")) { unlink $stale; }

    # Start recording immediately to prebuffer — no metadata yet
    _startPrebuffer($playerID, $prebuf, $metaSidecar);

    # After delay, get metadata and write sidecar for capture.sh to pick up
    my $delay = $prefs->get('startDelay') // 0;
    Slim::Utils::Timers::setTimer($client, time() + $delay, sub {
        my $c        = shift or return;
        my $s        = Slim::Player::Playlist::song($c) or return;
        my %meta     = _getMeta($c, $s);
        $log->info("Capturing: $meta{artist} - $meta{title}");

        # Write metadata sidecar for capture.sh
        _writeMetaSidecar($metaSidecar, \%meta, _outputDir());
    });
}

sub _getMeta {
    my ($client, $track) = @_;
    my %meta;

    eval {
        my $song = $client->controller()->streamingSong();
        if ($song) {
            my $r = $song->pluginData('info') // {};
            if ($r->{title}) {
                %meta = (
                    title    => $r->{title}                  || '',
                    artist   => $r->{artist}                 || '',
                    album    => $r->{album}                  || '',
                    year     => $r->{year}                   || '',
                    tracknum => $r->{tracknum}               || '',
                    artwork  => $r->{cover} || $r->{artwork} || '',
                    duration => $r->{duration} || $client->controller()->playingSongDuration() || 0,
                );
            }
        }
    };

    unless ($meta{title}) {
        %meta = (
            title    => $track->title()      || 'Unknown Title',
            artist   => $track->artistName() || 'Unknown Artist',
            album    => $track->album()      || 'Unknown Album',
            year     => $track->year()       || '',
            tracknum => $track->tracknum()   || '',
            artwork  => $track->coverurl()   || '',
            duration => $client->controller()->playingSongDuration() || $track->secs() || 0,
        );
    }

    return %meta;
}

sub _outputDir {
    if ($prefs->get('useNas')) {
        my $nasDir   = $prefs->get('nasDir') || '/mnt/nas/Spotify';
        my $nasMount = $nasDir;
        $nasMount =~ s|(/mnt/[^/]+).*|$1|;
        if (-d $nasMount && $nasMount ne '/mnt') {
            return $nasDir;
        }
        $log->warn("NAS selected but mount point not available ($nasMount) - falling back to local");
    }
    return $prefs->get('outputDir') || '/mnt/mmcblk0p2/Spotty';
}

sub _startPrebuffer {
    my ($playerID, $prebuf, $metaSidecar) = @_;

    # Prevent duplicate — check if already starting this exact prebuffer
    return if $startingPrebuf{$playerID} && $startingPrebuf{$playerID} eq $prebuf;
    $startingPrebuf{$playerID} = $prebuf;

    my $script = _pluginDir() . '/Bin/capture.sh';
    chmod 0755, $script if -f $script && !-x $script;
    unless (-x $script) {
        $log->error("capture.sh not found or not executable: $script");
        delete $startingPrebuf{$playerID};
        return;
    }

    my $pid = fork();
    if (!defined $pid) {
        $log->error("fork failed: $!");
        delete $startingPrebuf{$playerID};
        return;
    } elsif ($pid == 0) {
        exec($script,
            '--prebuffer', $prebuf,
            '--sidecar',   $metaSidecar,
            '--playerid',  $playerID,
            '--device',    $prefs->get('alsaDev'),
            '--bitrate',   $prefs->get('bitrate'),
            '--trim',      $prefs->get('endTrim') // 2.0,
        );
        exit 1;
    }

    delete $startingPrebuf{$playerID};
    $captureProc{$playerID} = $pid;
    $log->info("Prebuffer started PID $pid for player $playerID -> $prebuf");
}

sub _writeMetaSidecar {
    my ($path, $meta, $outDir) = @_;
    open(my $fh, '>', $path) or do {
        $log->error("Cannot write meta sidecar: $!");
        return;
    };
    binmode($fh, ':utf8');
    # Write as shell variables for capture.sh to dot-source.
    # Single quotes in values are escaped as '\'' for shell safety.
    for my $k (keys %$meta) {
        my $v = $meta->{$k} // '';
        $v =~ s/'/'\\''/g;
        print $fh uc($k) . "='" . $v . "'\n";
    }
    print $fh "OUTDIR='" . $outDir . "'\n";
    close $fh;
}

sub _stopCapture {
    my ($playerID, $discard) = @_;
    my $pid = $captureProc{$playerID} or return;
    if ($discard) {
        $log->info("Discarding capture PID $pid (watchdog/stop event)");
        kill 'USR1', $pid;
    } else {
        $log->info("Stopping capture PID $pid");
        kill 'INT', $pid;
    }
    # Non-blocking reap (WNOHANG) — finalize can take several seconds and
    # a blocking waitpid here would freeze the LMS main loop
    Slim::Utils::Timers::setTimer(undef, time() + 10, sub { waitpid($pid, 1) });
    delete $captureProc{$playerID};
}

sub _pluginDir {
    my $dir = eval { Slim::Utils::PluginManager->allPlugins->{SpottyCapture}{basedir} } // '';
    return $dir if $dir && -d $dir;
    for my $path (
        '/usr/local/slimserver/Cache/InstalledPlugins/Plugins/SpottyCapture',
        '/mnt/mmcblk0p2/tce/slimserver/Cache/InstalledPlugins/Plugins/SpottyCapture',
    ) {
        return $path if -d $path;
    }
    return '';
}

sub _syncPage {
    my ($client, $params) = @_;

    my $syncScript = _pluginDir() . '/Bin/sync.sh';
    chmod 0755, $syncScript if -f $syncScript && !-x $syncScript;

    my $outDir  = _outputDir();
    my $syncDir = $prefs->get('syncDir') || '/mnt/nas/Spotify';

    $log->info("SpottyCapture manual sync: $outDir -> $syncDir");
    system("$syncScript '$outDir' '$syncDir' &");

    $params->{syncStarted} = 1;
    $params->{syncFrom}    = $outDir;
    $params->{syncTo}      = $syncDir;

    return Slim::Web::HTTP::filltemplatefile(
        'plugins/SpottyCapture/settings/basic.html', $params);
}

sub _sweepStaleCaptures {
    # Kill only ffmpeg processes recording to our prebuffer files (sc_pre_).
    # This pattern never matches Squeezelite or Spotty playback processes.
    # Uses 'ps aux' (BusyBox-compatible; PID is the first column).
    my @lines = `ps aux 2>/dev/null | grep '[s]c_pre_' | grep ffmpeg`;
    for my $line (@lines) {
        if ($line =~ /^\s*(\d+)\s/) {
            $log->warn("Killing orphaned capture ffmpeg PID $1 from previous run");
            kill 'INT', $1;
        }
    }
    # Remove stale temp files left in RAM
    unlink glob("/tmp/sc_pre_*.mp3");
    unlink glob("/tmp/sc_meta_*.sh");
}

sub _updateCron {
    my $syncScript = _pluginDir() . '/Bin/sync.sh';
    my $outDir     = $prefs->get('outputDir') || '/mnt/mmcblk0p2/Spotty';
    my $syncDir    = $prefs->get('syncDir')   || '/mnt/nas/Spotify';
    my $enabled    = $prefs->get('syncEnabled') ? 1 : 0;

    # Read current crontab
    my $crontab = `crontab -l 2>/dev/null` || '';

    # Remove any existing SpottyCapture sync entry
    $crontab =~ s/.*SpottyCaptureSync.*\n?//g;

    # Add new entry if enabled
    if ($enabled) {
        $crontab .= "0 2 * * * $syncScript '$outDir' '$syncDir' # SpottyCaptureSync\n";
        $log->info("SpottyCapture sync cron enabled: $outDir -> $syncDir");
    } else {
        $log->info("SpottyCapture sync cron disabled.");
    }

    # Write crontab
    open(my $fh, '|-', 'crontab -') or return;
    print $fh $crontab;
    close $fh;
}

sub getDisplayName { 'PLUGIN_SPOTTYCAPTURE_NAME' }
sub playerMenu     { undef }

sub shutdownPlugin {
    my $class = shift;
    _stopCapture($_, 1) for keys %captureProc;
}

1;
