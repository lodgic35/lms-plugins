package Plugins::SpottyCapture::Plugin;

use strict;
use base qw(Slim::Plugin::Base);

use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Slim::Utils::Timers;
use Slim::Control::Request;
use Time::HiRes qw(time);

my $log = Slim::Utils::Log->addLogCategory({
    'category'     => 'plugin.spottycapture',
    'defaultLevel' => 'INFO',
    'description'  => 'Spotty Capture',
});

my $prefs = preferences('plugin.spottycapture');

$prefs->init({
    enabled   => 0,
    outputDir => '/mnt/mmcblk0p2/Spotty',
    alsaDev   => 'plughw:1,1',
    bitrate   => '320k',
    useNas    => 0,
    nasDir    => '/mnt/nas/Spotify',
});

use constant TOGGLE_URL => 'plugins/SpottyCapture/toggle';
use constant ICON       => 'plugins/SpottyCapture/html/images/icon.png';

# Keyed by player ID — tracks active capture PIDs
our %captureProc;

sub initPlugin {
    my $class = shift;
    $class->SUPER::initPlugin(@_);

    require Plugins::SpottyCapture::Settings;
    Plugins::SpottyCapture::Settings->new($class);

    # Ensure capture.sh is executable — zip installs strip execute permissions
    my $script = _pluginDir() . '/Bin/capture.sh';
    chmod 0755, $script if -f $script && !-x $script;

    # Register CLI command for controller app toggle
    Slim::Control::Request::addDispatch(
        ['spottycapture', '_cmd'],
        [0, 1, 0, \&_cliHandler]
    );

    # Register web UI Extras menu item with toggle page
    Slim::Web::Pages->addPageFunction(TOGGLE_URL, \&_togglePage);
    Slim::Web::Pages->addPageLinks('plugins', {
        'PLUGIN_SPOTTYCAPTURE_NAME' => TOGGLE_URL
    });
    Slim::Web::Pages->addPageLinks('icons', {
        'PLUGIN_SPOTTYCAPTURE_NAME' => ICON
    });

    # Register Jive/controller app home screen item
    Slim::Control::Jive::registerPluginMenu([{
        text    => 'PLUGIN_SPOTTYCAPTURE_NAME',
        id      => 'spottyCaptureToggle',
        node    => 'plugins',
        weight  => 100,
        actions => {
            go => {
                cmd    => ['spottycapture', 'toggle'],
                player => 0,
            },
        },
    }]);

    Slim::Control::Request::subscribe(
        \&_playerEvent,
        [['playlist'], ['newsong', 'stop', 'pause']],
    );

    $log->info("SpottyCapture initialised. Enabled: " . ($prefs->get('enabled') ? 'yes' : 'no')
        . ". Output: " . _outputDir());
}

# ---------------------------------------------------------------------------
# Web UI toggle page — shows current state, toggles on button click
# ---------------------------------------------------------------------------
sub _togglePage {
    my ($client, $params) = @_;

    # If action=toggle, flip the state
    if ($params->{action} && $params->{action} eq 'toggle') {
        my $newState = $prefs->get('enabled') ? 0 : 1;
        $prefs->set('enabled', $newState);

        if (!$newState) {
            $log->info("SpottyCapture disabled via Extras toggle.");
            _stopCapture($_, 1) for keys %captureProc;
        } else {
            $log->info("SpottyCapture enabled via Extras toggle.");
        }
    }

    # Show status page with current state
    $params->{enabled}   = $prefs->get('enabled') ? 1 : 0;
    $params->{outputDir} = _outputDir();

    return Slim::Web::HTTP::filltemplatefile(
        'plugins/SpottyCapture/html/toggle.html', $params);
}

# ---------------------------------------------------------------------------
# CLI handler — handles 'spottycapture toggle' and 'spottycapture status'
# Used by Jive/controller apps
# ---------------------------------------------------------------------------
sub _cliHandler {
    my $request = shift;
    my $cmd     = $request->getParam('_cmd') // '';

    if ($cmd eq 'toggle') {
        my $newState = $prefs->get('enabled') ? 0 : 1;
        $prefs->set('enabled', $newState);

        if (!$newState) {
            $log->info("SpottyCapture disabled via CLI toggle.");
            _stopCapture($_, 1) for keys %captureProc;
        } else {
            $log->info("SpottyCapture enabled via CLI toggle.");
        }

        $request->addResult('enabled', $newState);
        $request->addResult('text',
            $newState ? 'Spotty Capture: ON' : 'Spotty Capture: OFF');
    }
    elsif ($cmd eq 'status') {
        $request->addResult('enabled', $prefs->get('enabled') ? 1 : 0);
        $request->addResult('output', _outputDir());
    }

    $request->setStatusDone();
}

sub _playerEvent {
    my $request = shift;
    my $client  = $request->client() or return;
    return unless $prefs->get('enabled');
    my $cmd = $request->getRequestString();
    if ($cmd =~ /newsong/) {
        _onNewSong($client);
    } elsif ($cmd =~ /stop|clear/) {
        # stop/clear = watchdog recovery or playlist end — discard capture
        _stopCapture($client->id(), 1);
    } elsif ($cmd =~ /pause/) {
        # pause = user action — save what we have
        _stopCapture($client->id(), 0);
    }
}

sub _onNewSong {
    my ($client) = @_;
    my $playerID = $client->id();

    _stopCapture($playerID);

    my $song = Slim::Player::Playlist::song($client) or return;
    my $url  = $song->url() // '';

    unless ($url =~ /spotify|spotty/i) {
        $log->debug("Skipping non-Spotify track: $url");
        return;
    }

    # Delay 3 seconds to allow Spotty time to populate track metadata
    Slim::Utils::Timers::setTimer($client, time() + 3, sub {
        my $c        = shift or return;
        my $playerID = $c->id();
        my $s        = Slim::Player::Playlist::song($c) or return;
        my %meta     = _getMeta($c, $s);
        $log->info("Capturing: $meta{artist} - $meta{title}");
        _startCapture($playerID, \%meta);
    });
}

sub _getMeta {
    my ($client, $track) = @_;
    my %meta;

    eval {
        my $song = $client->controller()->streamingSong();
        if ($song) {
            my $r = $song->pluginData('info') // {};
            if ($r->{title}) {
                %meta = (
                    title    => $r->{title}                  || '',
                    artist   => $r->{artist}                 || '',
                    album    => $r->{album}                  || '',
                    year     => $r->{year}                   || '',
                    tracknum => $r->{tracknum}               || '',
                    artwork  => $r->{cover} || $r->{artwork} || '',
                );
            }
        }
    };

    unless ($meta{title}) {
        %meta = (
            title    => $track->title()      || 'Unknown Title',
            artist   => $track->artistName() || 'Unknown Artist',
            album    => $track->album()      || 'Unknown Album',
            year     => $track->year()       || '',
            tracknum => $track->tracknum()   || '',
            artwork  => $track->coverurl()   || '',
        );
    }

    return %meta;
}

sub _outputDir {
    if ($prefs->get('useNas')) {
        my $nasDir   = $prefs->get('nasDir') || '/mnt/nas/Spotify';
        my $nasMount = $nasDir;
        $nasMount =~ s|(/mnt/[^/]+).*|$1|;
        if (-d $nasMount && $nasMount ne '/mnt') {
            return $nasDir;
        }
        $log->warn("NAS selected but mount point not available ($nasMount) - falling back to local");
    }
    return $prefs->get('outputDir') || '/mnt/mmcblk0p2/Spotty';
}

sub _startCapture {
    my ($playerID, $meta) = @_;

    my $script = _pluginDir() . '/Bin/capture.sh';
    unless (-x $script) {
        $log->error("capture.sh not found or not executable: $script");
        return;
    }

    my $metaFile = "/tmp/sc_${playerID}.json";
    $metaFile =~ s/[^a-zA-Z0-9_\-\/\.]/_/g;

    open(my $fh, '>', $metaFile) or do {
        $log->error("Cannot write metadata: $!");
        return;
    };
    binmode($fh, ':utf8');
    print $fh _toJson($meta);
    close $fh;

    my $outDir = _outputDir();
    $log->info("Output directory: $outDir");

    my $pid = fork();
    if (!defined $pid) {
        $log->error("fork failed: $!");
        return;
    } elsif ($pid == 0) {
        exec($script,
            '--meta',    $metaFile,
            '--device',  $prefs->get('alsaDev'),
            '--outdir',  $outDir,
            '--bitrate', $prefs->get('bitrate'),
        );
        exit 1;
    }

    $captureProc{$playerID} = $pid;
    $log->info("Capture started PID $pid for player $playerID");
}

sub _stopCapture {
    my ($playerID, $discard) = @_;
    my $pid = $captureProc{$playerID} or return;
    if ($discard) {
        $log->info("Discarding capture PID $pid (watchdog/stop event)");
        kill 'USR1', $pid;  # SIGUSR1 = discard signal
    } else {
        $log->info("Stopping capture PID $pid");
        kill 'INT', $pid;
    }
    Slim::Utils::Timers::setTimer(undef, time() + 3, sub { waitpid($pid, 0) });
    delete $captureProc{$playerID};
}

sub _toJson {
    my ($meta) = @_;
    my $json = '{';
    for my $k (keys %$meta) {
        my $v = $meta->{$k} // '';
        $v =~ s/\\/\\\\/g;
        $v =~ s/"/\\"/g;
        $json .= "\"$k\":\"$v\",";
    }
    $json =~ s/,$//;
    $json .= '}';
    return $json;
}

sub _pluginDir {
    my $dir = eval { Slim::Utils::PluginManager->allPlugins->{SpottyCapture}{basedir} } // '';
    return $dir if $dir && -d $dir;
    for my $path (
        '/usr/local/slimserver/Cache/InstalledPlugins/Plugins/SpottyCapture',
        '/mnt/mmcblk0p2/tce/slimserver/Cache/InstalledPlugins/Plugins/SpottyCapture',
    ) {
        return $path if -d $path;
    }
    return '';
}

sub getDisplayName { 'PLUGIN_SPOTTYCAPTURE_NAME' }
sub playerMenu     { undef }

sub shutdownPlugin {
    my $class = shift;
    _stopCapture($_, 1) for keys %captureProc;
}

1;
