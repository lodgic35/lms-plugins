package Plugins::SpottyCapture::Plugin;

use strict;
use base qw(Slim::Plugin::Base);

use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Slim::Utils::Timers;
use Slim::Control::Request;
use Time::HiRes qw(time);

my $log = Slim::Utils::Log->addLogCategory({
    'category'     => 'plugin.spottycapture',
    'defaultLevel' => 'INFO',
    'description'  => 'Spotty Capture',
});

my $prefs = preferences('plugin.spottycapture');

$prefs->init({
    enabled   => 0,
    outputDir => '/mnt/mmcblk0p2/Spotty',
    alsaDev   => 'plughw:1,1',
    bitrate   => '320k',
    useNas    => 0,
    nasDir    => '/mnt/nas/Spotify',
});

# Keyed by player ID — tracks active capture PIDs
our %captureProc;

sub initPlugin {
    my $class = shift;
    $class->SUPER::initPlugin(@_);

    require Plugins::SpottyCapture::Settings;
    Plugins::SpottyCapture::Settings->new($class);

    # Ensure capture.sh is executable — zip installs strip execute permissions
    my $script = _pluginDir() . '/Bin/capture.sh';
    chmod 0755, $script if -f $script && !-x $script;

    # Register CLI command for the home screen toggle
    Slim::Control::Request::addDispatch(
        ['spottycapture', '_cmd'],
        [0, 1, 0, \&_cliHandler]
    );

    # Register home screen menu item
    if (Slim::Utils::PluginManager->isEnabled('Slim::Plugin::DontStopTheMusic::Plugin')
        || 1) {  # always register
        _registerJiveMenu($class);
    }

    Slim::Control::Request::subscribe(
        \&_playerEvent,
        [['playlist'], ['newsong', 'stop', 'pause']],
    );

    $log->info("SpottyCapture initialised. Enabled: " . ($prefs->get('enabled') ? 'yes' : 'no')
        . ". Output: " . _outputDir());
}

sub _registerJiveMenu {
    my $class = shift;

    my $enabled = $prefs->get('enabled') ? 1 : 0;

    Slim::Control::Jive::registerPluginMenu([{
        text    => 'PLUGIN_SPOTTYCAPTURE_NAME',
        id      => 'spottyCaptureToggle',
        node    => 'home',
        weight  => 100,
        actions => {
            go => {
                cmd    => ['spottycapture', 'toggle'],
                player => 0,
            },
        },
        window => {
            titleStyle => 'album',
        },
    }]);
}

# ---------------------------------------------------------------------------
# CLI handler — handles 'spottycapture toggle' and 'spottycapture status'
# ---------------------------------------------------------------------------
sub _cliHandler {
    my $request = shift;
    my $cmd     = $request->getParam('_cmd') // '';

    if ($cmd eq 'toggle') {
        my $newState = $prefs->get('enabled') ? 0 : 1;
        $prefs->set('enabled', $newState);

        if (!$newState) {
            $log->info("SpottyCapture disabled via home screen toggle.");
            _stopCapture($_) for keys %captureProc;
        } else {
            $log->info("SpottyCapture enabled via home screen toggle.");
        }

        $request->addResult('enabled', $newState);
        $request->addResult('text',
            $newState ? 'Spotty Capture: ON' : 'Spotty Capture: OFF');
    }
    elsif ($cmd eq 'status') {
        $request->addResult('enabled', $prefs->get('enabled') ? 1 : 0);
        $request->addResult('output', _outputDir());
    }

    $request->setStatusDone();
}

sub _playerEvent {
    my $request = shift;
    my $client  = $request->client() or return;
    return unless $prefs->get('enabled');
    my $cmd = $request->getRequestString();
    if ($cmd =~ /newsong/) {
        _onNewSong($client);
    } elsif ($cmd =~ /stop|pause/) {
        _stopCapture($client->id());
    }
}

sub _onNewSong {
    my ($client) = @_;
    my $playerID = $client->id();

    _stopCapture($playerID);

    my $song = Slim::Player::Playlist::song($client) or return;
    my $url  = $song->url() // '';

    unless ($url =~ /spotify|spotty/i) {
        $log->debug("Skipping non-Spotify track: $url");
        return;
    }

    # Delay 3 seconds to allow Spotty time to populate track metadata
    Slim::Utils::Timers::setTimer($client, time() + 3, sub {
        my $c        = shift or return;
        my $playerID = $c->id();
        my $s        = Slim::Player::Playlist::song($c) or return;
        my %meta     = _getMeta($c, $s);
        $log->info("Capturing: $meta{artist} - $meta{title}");
        _startCapture($playerID, \%meta);
    });
}

sub _getMeta {
    my ($client, $track) = @_;
    my %meta;

    # Try Spotty plugin metadata first.
    # Spotty stores track info under pluginData('info'), not pluginData('meta').
    # The 'cover' field holds the artwork URL in Spotty's data structure.
    eval {
        my $song = $client->controller()->streamingSong();
        if ($song) {
            my $r = $song->pluginData('info') // {};
            if ($r->{title}) {
                %meta = (
                    title    => $r->{title}                  || '',
                    artist   => $r->{artist}                 || '',
                    album    => $r->{album}                  || '',
                    year     => $r->{year}                   || '',
                    tracknum => $r->{tracknum}               || '',
                    artwork  => $r->{cover} || $r->{artwork} || '',
                );
            }
        }
    };

    # Fall back to LMS track object (for non-Spotify or if Spotty data unavailable)
    unless ($meta{title}) {
        %meta = (
            title    => $track->title()      || 'Unknown Title',
            artist   => $track->artistName() || 'Unknown Artist',
            album    => $track->album()      || 'Unknown Album',
            year     => $track->year()       || '',
            tracknum => $track->tracknum()   || '',
            artwork  => $track->coverurl()   || '',
        );
    }

    return %meta;
}

sub _outputDir {
    # Returns the active output directory based on NAS toggle.
    # Falls back to local if NAS is selected but not mounted.
    if ($prefs->get('useNas')) {
        my $nasDir   = $prefs->get('nasDir') || '/mnt/nas/Spotify';
        my $nasMount = $nasDir;
        $nasMount =~ s|(/mnt/[^/]+).*|$1|;
        if (-d $nasMount && $nasMount ne '/mnt') {
            return $nasDir;
        }
        $log->warn("NAS selected but mount point not available ($nasMount) - falling back to local");
    }
    return $prefs->get('outputDir') || '/mnt/mmcblk0p2/Spotty';
}

sub _startCapture {
    my ($playerID, $meta) = @_;

    my $script = _pluginDir() . '/Bin/capture.sh';
    unless (-x $script) {
        $log->error("capture.sh not found or not executable: $script");
        return;
    }

    my $metaFile = "/tmp/sc_${playerID}.json";
    $metaFile =~ s/[^a-zA-Z0-9_\-\/\.]/_/g;

    open(my $fh, '>', $metaFile) or do {
        $log->error("Cannot write metadata: $!");
        return;
    };
    binmode($fh, ':utf8');
    print $fh _toJson($meta);
    close $fh;

    my $outDir = _outputDir();
    $log->info("Output directory: $outDir");

    my $pid = fork();
    if (!defined $pid) {
        $log->error("fork failed: $!");
        return;
    } elsif ($pid == 0) {
        # Child: exec capture script — never returns
        exec($script,
            '--meta',    $metaFile,
            '--device',  $prefs->get('alsaDev'),
            '--outdir',  $outDir,
            '--bitrate', $prefs->get('bitrate'),
        );
        exit 1;
    }

    $captureProc{$playerID} = $pid;
    $log->info("Capture started PID $pid for player $playerID");
}

sub _stopCapture {
    my ($playerID) = @_;
    my $pid = $captureProc{$playerID} or return;
    $log->info("Stopping capture PID $pid");
    kill 'INT', $pid;
    # Reap the child after it finalises the MP3 (given 3 seconds)
    Slim::Utils::Timers::setTimer(undef, time() + 3, sub { waitpid($pid, 0) });
    delete $captureProc{$playerID};
}

sub _toJson {
    my ($meta) = @_;
    my $json = '{';
    for my $k (keys %$meta) {
        my $v = $meta->{$k} // '';
        $v =~ s/\\/\\\\/g;   # escape backslashes first
        $v =~ s/"/\\"/g;     # then escape quotes
        $json .= "\"$k\":\"$v\",";
    }
    $json =~ s/,$//;
    $json .= '}';
    return $json;
}

sub _pluginDir {
    # Try LMS plugin manager first (works for any install location)
    my $dir = eval { Slim::Utils::PluginManager->allPlugins->{SpottyCapture}{basedir} } // '';
    return $dir if $dir && -d $dir;
    # Fallback paths for piCorePlayer
    for my $path (
        '/usr/local/slimserver/Cache/InstalledPlugins/Plugins/SpottyCapture',
        '/mnt/mmcblk0p2/tce/slimserver/Cache/InstalledPlugins/Plugins/SpottyCapture',
    ) {
        return $path if -d $path;
    }
    return '';
}

sub getDisplayName { 'PLUGIN_SPOTTYCAPTURE_NAME' }
sub playerMenu     { undef }

sub shutdownPlugin {
    my $class = shift;
    _stopCapture($_) for keys %captureProc;
}

1;
