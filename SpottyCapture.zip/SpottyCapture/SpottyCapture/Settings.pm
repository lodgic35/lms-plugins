package Plugins::SpottyCapture::Settings;

use strict;
use base qw(Slim::Web::Settings);

use Slim::Utils::Prefs;
use Slim::Utils::Log;

my $prefs = preferences('plugin.spottycapture');
my $log   = logger('plugin.spottycapture');

sub name { Slim::Web::HTTP::CSRF->protectName('PLUGIN_SPOTTYCAPTURE_SETTINGS') }

sub page { Slim::Web::HTTP::CSRF->protectURI('plugins/SpottyCapture/settings/basic.html') }

sub prefs {
    return ($prefs, qw(enabled outputDir alsaDev bitrate));
}

sub handler {
    my ($class, $client, $paramRef, $pageSetup) = @_;

    if ($paramRef->{saveSettings}) {
        if (!$paramRef->{pref_enabled} && $prefs->get('enabled')) {
            $log->info("SpottyCapture disabled — stopping active captures.");
            Plugins::SpottyCapture::Plugin::_stopCapture($_)
                for keys %Plugins::SpottyCapture::Plugin::captureProc;
        }
    }

    $paramRef->{depStatus} = _checkDeps();

    return $class->SUPER::handler($client, $paramRef, $pageSetup);
}

sub _checkDeps {
    my @deps;
    for my $cmd (qw(ffmpeg curl perl)) {
        my $ok = (system("which $cmd >/dev/null 2>&1") == 0);
        push @deps, { name => $cmd, ok => $ok };
    }
    my $lb = (`aplay -l 2>/dev/null` =~ /Loopback/) ? 1 : 0;
    push @deps, { name => 'ALSA Loopback (snd-aloop)', ok => $lb };
    return \@deps;
}

1;
