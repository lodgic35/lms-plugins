package Plugins::SpottyCapture::Plugin;

use strict;
use base qw(Slim::Plugin::Base);

use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Slim::Utils::Timers;
use Slim::Control::Request;
use Time::HiRes qw(time);

my $log = Slim::Utils::Log->addLogCategory({
    'category'     => 'plugin.spottycapture',
    'defaultLevel' => 'INFO',
    'description'  => 'Spotty Capture',
});

my $prefs = preferences('plugin.spottycapture');

$prefs->init({
    enabled   => 0,
    outputDir => '/mnt/mmcblk0p2/Spotty',
    alsaDev   => 'plughw:1,1',
    bitrate   => '320k',
});

our %captureProc;

sub initPlugin {
    my $class = shift;
    $class->SUPER::initPlugin(@_);

    require Plugins::SpottyCapture::Settings;
    Plugins::SpottyCapture::Settings->new($class);

    Slim::Control::Request::subscribe(
        \&_playerEvent,
        [['playlist'], ['newsong', 'stop', 'pause']],
    );

    $log->info("SpottyCapture initialised. Enabled: " . ($prefs->get('enabled') ? 'yes' : 'no'));
}

sub _playerEvent {
    my $request = shift;
    my $client  = $request->client() or return;
    return unless $prefs->get('enabled');
    my $cmd = $request->getRequestString();
    if ($cmd =~ /newsong/) {
        _onNewSong($client);
    } elsif ($cmd =~ /stop|pause/) {
        _stopCapture($client->id());
    }
}

sub _onNewSong {
    my ($client) = @_;
    my $playerID = $client->id();

    _stopCapture($playerID);

    my $song = Slim::Player::Playlist::song($client) or return;
    my $url  = $song->url() // '';

    unless ($url =~ /spotify|spotty/i) {
        $log->debug("Skipping non-Spotify track: $url");
        return;
    }

    # Delay 3 seconds to let Spotty populate metadata
    Slim::Utils::Timers::setTimer($client, time() + 3, sub {
        my $c   = shift or return;
        my $pid = $c->id();
        my $s   = Slim::Player::Playlist::song($c) or return;
        my %meta = _getMeta($c, $s);
        $log->info("Capturing: $meta{artist} - $meta{title}");
        _startCapture($pid, \%meta);
    });
}

sub _getMeta {
    my ($client, $track) = @_;
    my %meta;

    # Try Spotty plugin metadata first
    eval {
        my $song = $client->controller()->streamingSong();
        if ($song) {
            my $r = $song->pluginData('info') // {};
            if ($r->{title}) {
                %meta = (
                    title    => $r->{title}    || '',
                    artist   => $r->{artist}   || '',
                    album    => $r->{album}    || '',
                    year     => $r->{year}     || '',
                    tracknum => $r->{tracknum} || '',
                    artwork  => $r->{cover} || $r->{artwork}    || '',
                );
            }
        }
    };

    # Fall back to LMS track object
    unless ($meta{title}) {
        %meta = (
            title    => $track->title()      || 'Unknown Title',
            artist   => $track->artistName() || 'Unknown Artist',
            album    => $track->album()      || 'Unknown Album',
            year     => $track->year()       || '',
            tracknum => $track->tracknum()   || '',
            artwork  => $track->coverurl()   || '',
        );
    }

    return %meta;
}

sub _startCapture {
    my ($playerID, $meta) = @_;

    my $script = _pluginDir() . '/Bin/capture.sh';
    unless (-x $script) {
        $log->error("capture.sh not found or not executable: $script");
        return;
    }

    my $metaFile = "/tmp/sc_${playerID}.json";
    $metaFile =~ s/[^a-zA-Z0-9_\-\/\.]/_/g;

    open(my $fh, '>', $metaFile) or do {
        $log->error("Cannot write metadata: $!");
        return;
    };
    binmode($fh, ":utf8");
    print $fh _toJson($meta);
    close $fh;

    my $pid = fork();
    if (!defined $pid) {
        $log->error("fork failed: $!");
        return;
    } elsif ($pid == 0) {
        exec($script,
            '--meta',    $metaFile,
            '--device',  $prefs->get('alsaDev'),
            '--outdir',  $prefs->get('outputDir'),
            '--bitrate', $prefs->get('bitrate'),
        );
        exit 1;
    }

    $captureProc{$playerID} = $pid;
    $log->info("Capture started PID $pid for player $playerID");
}

sub _stopCapture {
    my ($playerID) = @_;
    my $pid = $captureProc{$playerID} or return;
    $log->info("Stopping capture PID $pid");
    kill 'INT', $pid;
    Slim::Utils::Timers::setTimer(undef, time() + 3, sub { waitpid($pid, 0) });
    delete $captureProc{$playerID};
}

sub _toJson {
    my ($meta) = @_;
    my $json = '{';
    for my $k (keys %$meta) {
        my $v = $meta->{$k} // '';
        $v =~ s/"/\\"/g;
        $json .= "\"$k\":\"$v\",";
    }
    $json =~ s/,$//;
    $json .= '}';
    return $json;
}

sub _pluginDir {
    return '/mnt/mmcblk0p2/tce/slimserver/Cache/InstalledPlugins/Plugins/SpottyCapture';
}

sub getDisplayName { 'PLUGIN_SPOTTYCAPTURE_NAME' }
sub playerMenu     { undef }

sub shutdownPlugin {
    my $class = shift;
    _stopCapture($_) for keys %captureProc;
}

1;