package Plugins::StreamWatchdog::Plugin;

# StreamWatchdog - LMS Plugin v1.3
# Monitors players and automatically restarts playback if audio stops
# unexpectedly. Handles both Spotty/Spotify and internet radio streams.
#
# Detection methods:
#   1. Player mode changes to 'stop' unexpectedly
#   2. Player stays in 'play' mode but track time position freezes (hang detection)
#
# Recovery paths:
#   Spotify -> token refresh, stop/play cycle, then skip track
#   Radio   -> simple play retry with backoff

use strict;
use base qw(Slim::Plugin::Base);

use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Slim::Utils::Timers;
use Slim::Player::Client;
use Slim::Player::Source;
use Slim::Control::Request;
use Time::HiRes qw(time);

my $log = Slim::Utils::Log->addLogCategory({
    'category'     => 'plugin.streamwatchdog',
    'defaultLevel' => 'INFO',
    'description'  => 'Stream Watchdog',
});

my $prefs = preferences('plugin.streamwatchdog');

$prefs->init({
    enabled          => 1,
    poll_interval    => 15,
    debounce_delay   => 10,
    max_retries      => 5,
    backoff_seconds  => 30,
    cooldown_minutes => 10,
    freeze_threshold => 30,
});

my %playerState;

sub initPlugin {
    my $class = shift;
    $class->SUPER::initPlugin(@_);

    require Plugins::StreamWatchdog::Settings;
    Plugins::StreamWatchdog::Settings->new($class);

    Slim::Control::Request::subscribe(
        \&_onPlayerCommand,
        [['playlist'], ['play', 'pause', 'stop', 'clear', 'index']]
    );

    Slim::Control::Request::subscribe(
        \&_onPowerCommand,
        [['power']]
    );

    _schedulePoll();

    $log->info("Stream Watchdog v1.3 initialised. Poll interval: "
        . $prefs->get('poll_interval') . "s, Freeze threshold: "
        . $prefs->get('freeze_threshold') . "s");
}

sub _schedulePoll {
    Slim::Utils::Timers::killTimers(undef, \&_pollAllPlayers);
    Slim::Utils::Timers::setTimer(
        undef,
        time() + $prefs->get('poll_interval'),
        \&_pollAllPlayers
    );
}

sub _onPlayerCommand {
    my $request = shift;
    my $client  = $request->client() or return;
    my $id      = $client->id();
    my $cmd     = $request->getRequest(1) // '';

    if ($cmd eq 'play') {
        $playerState{$id}{userStopped}       = 0;
        $playerState{$id}{retries}           = 0;
        $playerState{$id}{stopTime}          = undef;
        $playerState{$id}{cooldownUntil}     = 0;
        $playerState{$id}{lastPlayTime}      = time();
        $playerState{$id}{hangDetected}      = 0;
        $playerState{$id}{lastTrackTime}     = undef;
        $playerState{$id}{lastTrackTimeSeen} = time();
        _recordTrackInfo($client);
        $log->debug("[$id] User play - watchdog reset");

    } elsif ($cmd eq 'pause') {
        $playerState{$id}{userStopped}  = 1;
        $playerState{$id}{hangDetected} = 0;
        $log->debug("[$id] User pause - watchdog suppressed");

    } elsif ($cmd eq 'stop' || $cmd eq 'clear') {
        $playerState{$id}{userStopped}  = 1;
        $playerState{$id}{retries}      = 0;
        $playerState{$id}{hangDetected} = 0;
        $log->debug("[$id] User stop/clear - watchdog suppressed");

    } elsif ($cmd eq 'index') {
        $playerState{$id}{userStopped}       = 0;
        $playerState{$id}{retries}           = 0;
        $playerState{$id}{stopTime}          = undef;
        $playerState{$id}{hangDetected}      = 0;
        $playerState{$id}{lastTrackTime}     = undef;
        $playerState{$id}{lastTrackTimeSeen} = time();
        _recordTrackInfo($client);
        $log->debug("[$id] User skip - watchdog reset");
    }
}

sub _onPowerCommand {
    my $request = shift;
    my $client  = $request->client() or return;
    my $id      = $client->id();
    my $power   = $request->getParam('_newvalue') // 1;
    if (!$power) {
        $playerState{$id}{userStopped}  = 1;
        $playerState{$id}{hangDetected} = 0;
        $log->debug("[$id] Power off - watchdog suppressed");
    }
}

sub _recordTrackInfo {
    my $client = shift;
    my $id     = $client->id();
    my $url    = Slim::Player::Playlist::url($client) // '';

    $playerState{$id}{lastURI}           = $url;
    $playerState{$id}{lastPlaylistIndex} = Slim::Player::Source::streamingSongIndex($client) // 0;

    if ($url =~ /^spotty:|spotify:|^https?:\/\/.*spotify/i) {
        $playerState{$id}{sourceType} = 'spotify';
    } elsif ($url =~ /^https?:\/\//i) {
        $playerState{$id}{sourceType} = 'radio';
    } else {
        $playerState{$id}{sourceType} = 'unknown';
    }

    $log->debug("[$id] Recorded: $url (type: $playerState{$id}{sourceType})");
}

sub _pollAllPlayers {
    _schedulePoll();
    return unless $prefs->get('enabled');
    for my $client (Slim::Player::Client::clients()) {
        next unless $client->isPlayer();
        _checkPlayer($client);
    }
}

sub _checkPlayer {
    my $client = shift;
    my $id     = $client->id();

    return unless $client->power();

    my $mode = Slim::Player::Source::playmode($client);

    if ($mode eq 'play') {
        _checkForHang($client);
        return;
    }

    # Not playing
    $playerState{$id}{hangDetected}      = 0;
    $playerState{$id}{lastTrackTime}     = undef;
    $playerState{$id}{lastTrackTimeSeen} = undef;

    return if $playerState{$id}{userStopped};
    return unless $playerState{$id}{lastPlayTime};

    my $cooldownUntil = $playerState{$id}{cooldownUntil} // 0;
    if (time() < $cooldownUntil) {
        $log->debug("[$id] In cooldown");
        return;
    }

    unless ($playerState{$id}{stopTime}) {
        $playerState{$id}{stopTime} = time();
        $log->info("[$id] Unexpected stop detected (mode: $mode) - debouncing");
        return;
    }

    my $debounce     = $prefs->get('debounce_delay');
    my $stopDuration = time() - $playerState{$id}{stopTime};
    if ($stopDuration < $debounce) {
        $log->debug("[$id] Debouncing ($stopDuration s < $debounce s)");
        return;
    }

    _attemptRecovery($client, 'unexpected stop');
}

sub _checkForHang {
    my $client      = shift;
    my $id          = $client->id();
    my $currentTime = $client->controller()->playingSongElapsed() // 0;
    my $lastTime    = $playerState{$id}{lastTrackTime};
    my $lastSeen    = $playerState{$id}{lastTrackTimeSeen} // time();

    if (!defined $lastTime) {
        $playerState{$id}{lastTrackTime}     = $currentTime;
        $playerState{$id}{lastTrackTimeSeen} = time();
        $playerState{$id}{lastPlayTime}      = time();
        _recordTrackInfo($client);
        $log->debug("[$id] Track time init: ${currentTime}s");
        return;
    }

    if ($currentTime != $lastTime) {
        $playerState{$id}{lastTrackTime}     = $currentTime;
        $playerState{$id}{lastTrackTimeSeen} = time();
        $playerState{$id}{lastPlayTime}      = time();
        $playerState{$id}{hangDetected}      = 0;
        $playerState{$id}{userStopped}       = 0;
        _recordTrackInfo($client);
        $log->debug("[$id] Track time advancing: ${currentTime}s");
        return;
    }

    my $frozenFor       = time() - $lastSeen;
    my $freezeThreshold = $prefs->get('freeze_threshold');

    $log->debug("[$id] Track time frozen at ${currentTime}s for ${frozenFor}s");

    if ($frozenFor >= $freezeThreshold) {
        my $cooldownUntil = $playerState{$id}{cooldownUntil} // 0;
        return if time() < $cooldownUntil;
        return if $playerState{$id}{userStopped};

        $log->warn("[$id] HANG DETECTED - frozen at ${currentTime}s for ${frozenFor}s");
        $playerState{$id}{hangDetected}      = 1;
        $playerState{$id}{lastTrackTime}     = undef;
        $playerState{$id}{lastTrackTimeSeen} = undef;

        # Set stopTime so backoff logic works
        $playerState{$id}{stopTime} = time() unless $playerState{$id}{stopTime};

        _attemptRecovery($client, 'hang');
    }
}

sub _attemptRecovery {
    my ($client, $reason) = @_;
    my $id         = $client->id();
    my $retries    = $playerState{$id}{retries} // 0;
    my $maxRetries = $prefs->get('max_retries');

    if ($retries >= $maxRetries) {
        my $cooldownSecs = $prefs->get('cooldown_minutes') * 60;
        $playerState{$id}{cooldownUntil} = time() + $cooldownSecs;
        $playerState{$id}{retries}       = 0;
        $playerState{$id}{stopTime}      = undef;
        $log->warn("[$id] Max retries reached - cooling down for "
            . $prefs->get('cooldown_minutes') . " minutes");
        return;
    }

    my $backoff  = $prefs->get('backoff_seconds') * (1 + $retries * 0.5);
    my $stopTime = $playerState{$id}{stopTime} // time();
    my $elapsed  = time() - $stopTime;

    if ($retries > 0 && $elapsed < $backoff) {
        $log->debug("[$id] Backoff wait ($elapsed s < $backoff s)");
        return;
    }

    $playerState{$id}{retries}++;
    my $attempt = $playerState{$id}{retries};
    my $source  = $playerState{$id}{sourceType} // 'unknown';

    $log->warn("[$id] Recovery attempt $attempt/$maxRetries - reason: $reason, source: $source");

    if ($source eq 'spotify') {
        _recoverSpotify($client);
    } elsif ($source eq 'radio') {
        _recoverRadio($client);
    } else {
        _recoverGeneric($client);
    }
}

sub _recoverSpotify {
    my $client  = shift;
    my $id      = $client->id();
    my $retries = $playerState{$id}{retries} // 1;

    $log->info("[$id] Spotify recovery: attempt $retries");

    my $playlistSize = Slim::Player::Playlist::count($client) // 0;
    my $currentIndex = Slim::Player::Source::streamingSongIndex($client) // 0;

    if ($retries <= 2) {
        # Token refresh then stop/play cycle to force reconnect
        $log->info("[$id] Spotify: token refresh + stop/play cycle");
        eval { $client->execute(['spotty', 'refresh']); };
        if ($@) { $log->warn("[$id] Spotty refresh failed: $@"); }

        Slim::Utils::Timers::setTimer(
            $client,
            time() + 3,
            sub {
                my $c = shift;
                return unless $c;
                my $cid = $c->id();
                $log->info("[$cid] Spotify: issuing stop");
                $c->execute(['stop']);
                Slim::Utils::Timers::setTimer(
                    $c,
                    time() + 2,
                    sub {
                        my $c2 = shift;
                        return unless $c2;
                        my $cid2 = $c2->id();
                        $log->info("[$cid2] Spotify: issuing play after stop");
                        $c2->execute(['play']);
                    }
                );
            }
        );

    } else {
        # Skip to next track
        $log->info("[$id] Spotify: skipping to next track (attempt $retries)");
        if ($playlistSize > 1 && $currentIndex < $playlistSize - 1) {
            $client->execute(['playlist', 'index', '+1']);
            $log->info("[$id] Spotify: skipped to track " . ($currentIndex + 2) . " of $playlistSize");
        } else {
            $log->info("[$id] Spotify: restarting from track 1");
            $client->execute(['playlist', 'index', '0']);
            Slim::Utils::Timers::setTimer(
                $client, time() + 1,
                sub {
                    my $c = shift;
                    return unless $c;
                    $c->execute(['play']);
                }
            );
        }
    }
}

sub _recoverRadio {
    my $client = shift;
    my $id     = $client->id();
    $log->info("[$id] Radio recovery: issuing play");
    $client->execute(['play']);
}

sub _recoverGeneric {
    my $client = shift;
    my $id     = $client->id();
    $log->info("[$id] Generic recovery: issuing play");
    $client->execute(['play']);
}

sub getDisplayName { 'PLUGIN_STREAMWATCHDOG' }
sub playerMenu     { undef }

1;
