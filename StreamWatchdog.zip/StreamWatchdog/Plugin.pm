package Plugins::StreamWatchdog::Plugin;

# StreamWatchdog - LMS Plugin v1.2
# Monitors players and automatically restarts playback if audio stops
# unexpectedly. Handles both Spotty/Spotify and internet radio streams.
#
# Detection methods:
#   1. Player mode changes to 'stop' unexpectedly
#   2. Player stays in 'play' mode but track time position freezes (hang detection)
#
# Recovery paths:
#   Spotify (spotty:// or spotify: URIs) -> token refresh, skip broken track, re-queue
#   Radio   (http:// https://)           -> simple play retry with backoff

use strict;
use base qw(Slim::Plugin::Base);

use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Slim::Utils::Timers;
use Slim::Player::Client;
use Slim::Player::Source;
use Slim::Control::Request;
use Time::HiRes qw(time);

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
my $log = Slim::Utils::Log->addLogCategory({
    'category'     => 'plugin.streamwatchdog',
    'defaultLevel' => 'INFO',
    'description'  => 'Stream Watchdog',
});

# ---------------------------------------------------------------------------
# Preferences / defaults
# ---------------------------------------------------------------------------
my $prefs = preferences('plugin.streamwatchdog');

$prefs->init({
    enabled            => 1,
    poll_interval      => 15,   # seconds between status checks
    debounce_delay     => 10,   # seconds to wait before acting on a stop
    max_retries        => 5,    # attempts before cooldown
    backoff_seconds    => 30,   # base wait between retries
    cooldown_minutes   => 10,   # pause after max retries reached
    freeze_threshold   => 30,   # seconds of frozen time before treating as hang
});

# ---------------------------------------------------------------------------
# Per-player state tracking
# %playerState keys:
#   userStopped       => 1/0   - was the last stop user-initiated?
#   lastPlayTime      => epoch - when the player last entered 'play' mode
#   stopTime          => epoch - when the unexpected stop was first detected
#   retries           => int   - how many recovery attempts made
#   cooldownUntil     => epoch - don't retry until this time
#   lastURI           => str   - URI/URL of the last known playing track
#   lastPlaylistIndex => int   - playlist position when last playing
#   sourceType        => 'spotify'|'radio'|'unknown'
#   lastTrackTime     => float - last known track position in seconds
#   lastTrackTimeSeen => epoch - wall clock when we last saw track time change
#   hangDetected      => 1/0   - are we currently in hang recovery
# ---------------------------------------------------------------------------
my %playerState;

# ---------------------------------------------------------------------------
# Plugin initialisation
# ---------------------------------------------------------------------------
sub initPlugin {
    my $class = shift;
    $class->SUPER::initPlugin(@_);

    # Load settings page
    require Plugins::StreamWatchdog::Settings;
    Plugins::StreamWatchdog::Settings->new($class);

    # Subscribe to player command events to detect user-initiated stops
    Slim::Control::Request::subscribe(
        \&_onPlayerCommand,
        [['playlist'], ['play', 'pause', 'stop', 'clear', 'index']]
    );

    # Also watch for power off
    Slim::Control::Request::subscribe(
        \&_onPowerCommand,
        [['power']]
    );

    # Start the polling loop
    _schedulePoll();

    $log->info("Stream Watchdog v1.3 initialised. Poll interval: "
        . $prefs->get('poll_interval') . "s, Freeze threshold: "
        . $prefs->get('freeze_threshold') . "s");
}

# ---------------------------------------------------------------------------
# Schedule the next poll
# ---------------------------------------------------------------------------
sub _schedulePoll {
    Slim::Utils::Timers::killTimers(undef, \&_pollAllPlayers);
    Slim::Utils::Timers::setTimer(
        undef,
        time() + $prefs->get('poll_interval'),
        \&_pollAllPlayers
    );
}

# ---------------------------------------------------------------------------
# Command subscription: track user-initiated play/pause/stop
# ---------------------------------------------------------------------------
sub _onPlayerCommand {
    my $request = shift;
    my $client  = $request->client() or return;
    my $id      = $client->id();
    my $cmd     = $request->getRequest(1) // '';

    if ($cmd eq 'play') {
        # User started playback - clear watchdog flags
        $playerState{$id}{userStopped}      = 0;
        $playerState{$id}{retries}          = 0;
        $playerState{$id}{stopTime}         = undef;
        $playerState{$id}{cooldownUntil}    = 0;
        $playerState{$id}{lastPlayTime}     = time();
        $playerState{$id}{hangDetected}     = 0;
        $playerState{$id}{lastTrackTime}    = undef;
        $playerState{$id}{lastTrackTimeSeen} = time();
        _recordTrackInfo($client);
        $log->debug("[$id] User-initiated play - watchdog reset");

    } elsif ($cmd eq 'pause') {
        $playerState{$id}{userStopped}  = 1;
        $playerState{$id}{hangDetected} = 0;
        $log->debug("[$id] User pause - watchdog suppressed");

    } elsif ($cmd eq 'stop' || $cmd eq 'clear') {
        $playerState{$id}{userStopped}  = 1;
        $playerState{$id}{retries}      = 0;
        $playerState{$id}{hangDetected} = 0;
        $log->debug("[$id] User stop/clear - watchdog suppressed");

    } elsif ($cmd eq 'index') {
        # User manually skipped track - reset hang detection
        $playerState{$id}{userStopped}       = 0;
        $playerState{$id}{retries}           = 0;
        $playerState{$id}{stopTime}          = undef;
        $playerState{$id}{hangDetected}      = 0;
        $playerState{$id}{lastTrackTime}     = undef;
        $playerState{$id}{lastTrackTimeSeen} = time();
        _recordTrackInfo($client);
        $log->debug("[$id] User track skip - watchdog reset");
    }
}

sub _onPowerCommand {
    my $request = shift;
    my $client  = $request->client() or return;
    my $id      = $client->id();
    my $power   = $request->getParam('_newvalue') // 1;

    if (!$power) {
        $playerState{$id}{userStopped}  = 1;
        $playerState{$id}{hangDetected} = 0;
        $log->debug("[$id] Power off - watchdog suppressed");
    }
}

# ---------------------------------------------------------------------------
# Record current track info for potential recovery
# ---------------------------------------------------------------------------
sub _recordTrackInfo {
    my $client = shift;
    my $id     = $client->id();

    my $url = Slim::Player::Playlist::url($client) // '';
    $playerState{$id}{lastURI}           = $url;
    $playerState{$id}{lastPlaylistIndex} =
        Slim::Player::Source::streamingSongIndex($client) // 0;

    # Determine source type
    if ($url =~ /^spotty:|spotify:|^https?:\/\/.*spotify/i) {
        $playerState{$id}{sourceType} = 'spotify';
    } elsif ($url =~ /^https?:\/\//i) {
        $playerState{$id}{sourceType} = 'radio';
    } else {
        $playerState{$id}{sourceType} = 'unknown';
    }

    $log->debug("[$id] Recorded track: $url (type: $playerState{$id}{sourceType})");
}

# ---------------------------------------------------------------------------
# Main poll loop - called every poll_interval seconds
# ---------------------------------------------------------------------------
sub _pollAllPlayers {
    # Reschedule immediately so timer continues even if we die
    _schedulePoll();

    return unless $prefs->get('enabled');

    for my $client (Slim::Player::Client::clients()) {
        next unless $client->isPlayer();
        _checkPlayer($client);
    }
}

# ---------------------------------------------------------------------------
# Check a single player and trigger recovery if needed
# ---------------------------------------------------------------------------
sub _checkPlayer {
    my $client = shift;
    my $id     = $client->id();

    # Skip players that are powered off
    return unless $client->power();

    my $mode = Slim::Player::Source::playmode($client);

    if ($mode eq 'play') {
        # Check for hang - track time frozen while in play mode
        _checkForHang($client);
        return;
    }

    # --- Mode is not 'play' (stop or pause) ---

    # Reset hang detection since we're not playing
    $playerState{$id}{hangDetected}      = 0;
    $playerState{$id}{lastTrackTime}     = undef;
    $playerState{$id}{lastTrackTimeSeen} = undef;

    # Skip if this was user-initiated
    return if $playerState{$id}{userStopped};

    # Skip if we never saw this player playing
    return unless $playerState{$id}{lastPlayTime};

    # Skip if in cooldown
    my $cooldownUntil = $playerState{$id}{cooldownUntil} // 0;
    if (time() < $cooldownUntil) {
        $log->debug("[$id] In cooldown - skipping");
        return;
    }

    # Record when we first noticed the unexpected stop
    unless ($playerState{$id}{stopTime}) {
        $playerState{$id}{stopTime} = time();
        $log->info("[$id] Unexpected stop detected (mode: $mode) - starting debounce");
        return;
    }

    # Check debounce period
    my $debounce     = $prefs->get('debounce_delay');
    my $stopDuration = time() - $playerState{$id}{stopTime};
    if ($stopDuration < $debounce) {
        $log->debug("[$id] Debouncing ($stopDuration s < $debounce s)");
        return;
    }

    # Attempt recovery
    _attemptRecovery($client, 'unexpected stop');
}

# ---------------------------------------------------------------------------
# Hang detection - player in 'play' mode but time not advancing
# ---------------------------------------------------------------------------
sub _checkForHang {
    my $client = shift;
    my $id     = $client->id();

    # Get current track time via LMS internal API
    my $currentTime = $client->controller()->playingSongElapsed() // 0;

    my $lastTime     = $playerState{$id}{lastTrackTime};
    my $lastTimeSeen = $playerState{$id}{lastTrackTimeSeen} // time();

    if (!defined $lastTime) {
        # First reading - just record it
        $playerState{$id}{lastTrackTime}     = $currentTime;
        $playerState{$id}{lastTrackTimeSeen} = time();
        $playerState{$id}{lastPlayTime}      = time();
        _recordTrackInfo($client);
        $log->debug("[$id] Track time initialised: ${currentTime}s");
        return;
    }

    if ($currentTime != $lastTime) {
        # Time is advancing normally - update records and reset hang state
        $playerState{$id}{lastTrackTime}     = $currentTime;
        $playerState{$id}{lastTrackTimeSeen} = time();
        $playerState{$id}{lastPlayTime}      = time();
        $playerState{$id}{hangDetected}      = 0;
        $playerState{$id}{userStopped}       = 0;
        _recordTrackInfo($client);
        $log->debug("[$id] Track time advancing normally: ${currentTime}s");
        return;
    }

    # Time has not changed - check how long it's been frozen
    my $frozenFor     = time() - $lastTimeSeen;
    my $freezeThreshold = $prefs->get('freeze_threshold');

    $log->debug("[$id] Track time frozen at ${currentTime}s for ${frozenFor}s");

    if ($frozenFor >= $freezeThreshold) {

        # Skip if in cooldown
        my $cooldownUntil = $playerState{$id}{cooldownUntil} // 0;
        if (time() < $cooldownUntil) {
            $log->debug("[$id] Hang detected but in cooldown");
            return;
        }

        # Skip if user stopped
        return if $playerState{$id}{userStopped};

        $log->warn("[$id] HANG DETECTED - track time frozen at ${currentTime}s for ${frozenFor}s");
        $playerState{$id}{hangDetected} = 1;

        # Reset time tracking so we don't immediately re-trigger
        $playerState{$id}{lastTrackTime}     = undef;
        $playerState{$id}{lastTrackTimeSeen} = undef;

        _attemptRecovery($client, 'hang');
    }
}

# ---------------------------------------------------------------------------
# Central recovery dispatcher
# ---------------------------------------------------------------------------
sub _attemptRecovery {
    my ($client, $reason) = @_;
    my $id = $client->id();

    # Check retry limit
    my $retries    = $playerState{$id}{retries} // 0;
    my $maxRetries = $prefs->get('max_retries');

    if ($retries >= $maxRetries) {
        my $cooldownSecs = $prefs->get('cooldown_minutes') * 60;
        $playerState{$id}{cooldownUntil} = time() + $cooldownSecs;
        $playerState{$id}{retries}       = 0;
        $playerState{$id}{stopTime}      = undef;
        $log->warn("[$id] Max retries ($maxRetries) reached - cooling down for "
            . $prefs->get('cooldown_minutes') . " minutes");
        return;
    }

    # Backoff increases with each retry
    my $backoff = $prefs->get('backoff_seconds') * (1 + $retries * 0.5);
    my  =  // time();
    # For hangs, always set stopTime so backoff works correctly
    unless () {
         = time() - (->get('backoff_seconds') * (1 + (-1) * 0.5));
    }
    my $elapsed  = time() - $stopTime;

    if ($retries > 0 && $elapsed < $backoff) {
        $log->debug("[$id] Backoff wait ($elapsed s < $backoff s)");
        return;
    }

    $playerState{$id}{retries}++;
    my $attempt = $playerState{$id}{retries};
    my $source  = $playerState{$id}{sourceType} // 'unknown';

    $log->warn("[$id] Recovery attempt $attempt/$maxRetries - reason: $reason, source: $source");

    if ($source eq 'spotify') {
        _recoverSpotify($client);
    } elsif ($source eq 'radio') {
        _recoverRadio($client);
    } else {
        _recoverGeneric($client);
    }
}

# ---------------------------------------------------------------------------
# Spotify / Spotty recovery
# ---------------------------------------------------------------------------
sub _recoverSpotify {
    my $client  = shift;
    my $id      = $client->id();
    my $retries = $playerState{$id}{retries} // 1;
    my $isHang  = $playerState{$id}{hangDetected} // 0;

    $log->info("[$id] Spotify recovery: attempt $retries (hang: $isHang)");

    my $playlistSize = Slim::Player::Playlist::count($client) // 0;
    my $currentIndex = Slim::Player::Source::streamingSongIndex($client) // 0;

    if ($retries <= 2) {
        # First attempts: token refresh, then stop+play to force reconnect
        $log->info("[$id] Spotify: token refresh + stop/play");
        eval { $client->execute(['spotty', 'refresh']); };
        if ($@) { $log->warn("[$id] Spotty refresh failed: $@"); }

        Slim::Utils::Timers::setTimer(
            $client,
            time() + 3,
            sub {
                my $c = shift;
                return unless $c;
                my $cid = $c->id();
                $log->info("[$cid] Spotify: issuing stop then play to force reconnect");
                $c->execute(['stop']);
                Slim::Utils::Timers::setTimer(
                    $c,
                    time() + 2,
                    sub {
                        my $c2 = shift;
                        return unless $c2;
                        $log->info("[${ \$c2->id }] Spotify: issuing play after stop");
                        $c2->execute(['play']);
                    }
                );
            }
        );

    } else {
        # Later attempts: skip to next track entirely
        $log->info("[$id] Spotify: skipping to next track (attempt $retries)");

        if ($playlistSize > 1 && $currentIndex < $playlistSize - 1) {
            $client->execute(['playlist', 'index', '+1']);
            $log->info("[$id] Spotify: skipped to track " . ($currentIndex + 2) . " of $playlistSize");
        } else {
            $log->info("[$id] Spotify: restarting playlist from track 1");
            $client->execute(['playlist', 'index', '0']);
            Slim::Utils::Timers::setTimer(
                $client, time() + 1,
                sub { my $c = shift; $c && $c->execute(['play']); }
            );
        }
    }
}

        Slim::Utils::Timers::setTimer(
            $client,
            time() + 5,
            sub {
                my $c = shift;
                return unless $c;
                my $mode = Slim::Player::Source::playmode($c);
                if ($mode ne 'play') {
                    $log->info("[${ \$c->id }] Spotify: issuing play after token refresh");
                    $c->execute(['play']);
                } else {
                    # In play mode - check if time is advancing
                    $log->info("[${ \$c->id }] Spotify: play mode restored after token refresh");
                }
            }
        );

    } else {
        # Later attempts: skip to next track to get past broken one
        $log->info("[$id] Spotify: skipping to next track");
        my $playlistSize = Slim::Player::Playlist::count($client) // 0;
        my $currentIndex = Slim::Player::Source::streamingSongIndex($client) // 0;

        if ($playlistSize > 1 && $currentIndex < $playlistSize - 1) {
            $client->execute(['playlist', 'index', '+1']);
            $log->info("[$id] Spotify: skipped to track " . ($currentIndex + 2) . " of $playlistSize");
        } else {
            $log->info("[$id] Spotify: restarting playlist from track 1");
            $client->execute(['playlist', 'index', '0']);
            $client->execute(['play']);
        }
    }
}

# ---------------------------------------------------------------------------
# Internet radio recovery
# ---------------------------------------------------------------------------
sub _recoverRadio {
    my $client  = shift;
    my $id      = $client->id();
    my $retries = $playerState{$id}{retries} // 1;

    $log->info("[$id] Radio recovery: attempt $retries");
    $client->execute(['play']);
}

# ---------------------------------------------------------------------------
# Generic recovery
# ---------------------------------------------------------------------------
sub _recoverGeneric {
    my $client = shift;
    my $id     = $client->id();
    $log->info("[$id] Generic recovery: issuing play");
    $client->execute(['play']);
}

# ---------------------------------------------------------------------------
# Plugin metadata
# ---------------------------------------------------------------------------
sub getDisplayName { 'PLUGIN_STREAMWATCHDOG' }
sub playerMenu     { undef }

1;
