package Plugins::StreamWatchdog::Settings;

use strict;
use base qw(Slim::Web::Settings);

use Slim::Utils::Prefs;

my $prefs = preferences('plugin.streamwatchdog');

sub name { Slim::Web::HTTP::CSRF->protectName('PLUGIN_STREAMWATCHDOG_SETTINGS') }

sub page { Slim::Web::HTTP::CSRF->protectURI('plugins/StreamWatchdog/settings/basic.html') }

sub prefs {
    return ($prefs,
        qw(enabled poll_interval debounce_delay max_retries backoff_seconds
           cooldown_minutes freeze_threshold fallback_enabled fallback_url
           fallback_title ping_host silence_enabled silence_timeout
           silence_fallback_url silence_fallback_title silence_repeat
           startup_enabled startup_url startup_title startup_delay startup_repeat)
    );
}

sub handler {
    my ($class, $client, $paramRef, $pageSetup) = @_;

    $paramRef->{favourites} = Plugins::StreamWatchdog::Plugin::getFavourites();

    if ($paramRef->{saveSettings}) {
        # Save recovery fallback title
        if ($paramRef->{pref_fallback_url}) {
            for my $fav (@{$paramRef->{favourites}}) {
                if ($fav->{id} eq $paramRef->{pref_fallback_url}) {
                    $prefs->set('fallback_title', $fav->{title});
                    last;
                }
            }
        }
        # Save silence fallback title
        if ($paramRef->{pref_silence_fallback_url}) {
            for my $fav (@{$paramRef->{favourites}}) {
                if ($fav->{id} eq $paramRef->{pref_silence_fallback_url}) {
                    $prefs->set('silence_fallback_title', $fav->{title});
                    last;
                }
            }
        }
        # Save startup title
        if ($paramRef->{pref_startup_url}) {
            for my $fav (@{$paramRef->{favourites}}) {
                if ($fav->{id} eq $paramRef->{pref_startup_url}) {
                    $prefs->set('startup_title', $fav->{title});
                    last;
                }
            }
        }
    }

    return $class->SUPER::handler($client, $paramRef, $pageSetup);
}

1;
