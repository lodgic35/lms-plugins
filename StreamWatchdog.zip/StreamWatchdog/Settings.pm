package Plugins::StreamWatchdog::Settings;

use strict;
use base qw(Slim::Web::Settings);

use Slim::Utils::Prefs;

my $prefs = preferences('plugin.streamwatchdog');

sub name { Slim::Web::HTTP::CSRF->protectName('PLUGIN_STREAMWATCHDOG_SETTINGS') }

sub page { Slim::Web::HTTP::CSRF->protectURI('plugins/StreamWatchdog/settings/basic.html') }

sub prefs {
    return ($prefs,
        qw(enabled poll_interval debounce_delay max_retries backoff_seconds cooldown_minutes)
    );
}

1;
