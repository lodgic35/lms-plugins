package Plugins::StreamWatchdog::Settings;

use strict;
use base qw(Slim::Web::Settings);

use Slim::Utils::Prefs;

my $prefs = preferences('plugin.streamwatchdog');

sub name { Slim::Web::HTTP::CSRF->protectName('PLUGIN_STREAMWATCHDOG_SETTINGS') }

sub page { Slim::Web::HTTP::CSRF->protectURI('plugins/StreamWatchdog/settings/basic.html') }

sub prefs {
    return ($prefs,
        qw(enabled poll_interval debounce_delay max_retries backoff_seconds
           cooldown_minutes freeze_threshold fallback_enabled fallback_url
           fallback_title ping_host)
    );
}

sub handler {
    my ($class, $client, $paramRef, $pageSetup) = @_;

    # Load favourites for dropdown
    $paramRef->{favourites} = Plugins::StreamWatchdog::Plugin::getFavourites();

    # If fallback_url was just saved, find its title from favourites
    if ($paramRef->{saveSettings} && $paramRef->{pref_fallback_url}) {
        for my $fav (@{$paramRef->{favourites}}) {
            if ($fav->{id} eq $paramRef->{pref_fallback_url}) {
                $prefs->set('fallback_title', $fav->{title});
                last;
            }
        }
    }

    return $class->SUPER::handler($client, $paramRef, $pageSetup);
}

1;
