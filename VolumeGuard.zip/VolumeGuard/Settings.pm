package Plugins::VolumeGuard::Settings;

use strict;
use base qw(Slim::Web::Settings);

use Slim::Utils::Prefs;

my $prefs = preferences('plugin.volumeguard');

sub name { Slim::Web::HTTP::CSRF->protectName('PLUGIN_VOLUMEGUARD') }

sub page { Slim::Web::HTTP::CSRF->protectURI('plugins/VolumeGuard/settings/basic.html') }

sub prefs {
    return ($prefs, qw(enabled locked_volume));
}

sub handler {
    my ($class, $client, $paramRef, $pageSetup) = @_;

    my $lockedPlayers = $prefs->get('locked_players') || {};

    if ($paramRef->{saveSettings}) {
        my $newLocked = {};
        for my $c (Slim::Player::Client::clients()) {
            next unless $c->isPlayer();
            my $pid = $c->id();
            (my $safeid = $pid) =~ s/:/_/g;
            if ($paramRef->{"lock_player_$safeid"}) {
                $newLocked->{$pid} = 1;
            }
        }
        $prefs->set('locked_players', $newLocked);
        $lockedPlayers = $newLocked;

        Slim::Utils::Timers::setTimer(
            undef,
            Time::HiRes::time() + 1,
            \&Plugins::VolumeGuard::Plugin::applySettings
        );
    }

    my @players;
    for my $c (Slim::Player::Client::clients()) {
        next unless $c->isPlayer();
        my $pid = $c->id();
        (my $safeid = $pid) =~ s/:/_/g;
        push @players, {
            id     => $pid,
            safeid => $safeid,
            name   => $c->name() || $pid,
            locked => $lockedPlayers->{$pid} ? 1 : 0,
        };
    }
    $paramRef->{players} = \@players;

    return $class->SUPER::handler($client, $paramRef, $pageSetup);
}

1;
