package Plugins::VolumeGuard::Settings;

use strict;
use base qw(Slim::Web::Settings);

use Slim::Utils::Prefs;
use Slim::Utils::Log;

my $prefs = preferences('plugin.volumeguard');
my $log   = Slim::Utils::Log->addLogCategory({ 'category' => 'plugin.volumeguard' });

sub name   { 'PLUGIN_VOLUMEGUARD' }
sub page   { 'plugins/VolumeGuard/settings/basic.html' }

sub prefs {
    return ($prefs, qw(enabled locked_volume locked_players));
}

sub handler {
    my ($class, $client, $paramRef, $pageSetup) = @_;

    $paramRef->{players} = Plugins::VolumeGuard::Plugin::getPlayers();

    if ($paramRef->{saveSettings}) {
        # Build locked_players hash from checkboxes
        my $lockedPlayers = {};
        for my $player (@{$paramRef->{players}}) {
            my $pid = $player->{id};
            # Checkbox name: lock_player_<id with colons replaced by underscores>
            (my $safeid = $pid) =~ s/:/_/g;
            if ($paramRef->{"lock_player_$safeid"}) {
                $lockedPlayers->{$pid} = 1;
            }
        }
        $prefs->set('locked_players', $lockedPlayers);

        # Apply immediately
        Slim::Utils::Timers::setTimer(
            undef,
            Time::HiRes::time() + 1,
            \&Plugins::VolumeGuard::Plugin::applySettings
        );
    }

    # Pass locked_players to template
    $paramRef->{locked_players} = $prefs->get('locked_players') || {};

    return $class->SUPER::handler($client, $paramRef, $pageSetup);
}

1;
